<template>
    <div>
       <ul class="list-group"><!--Abajo para iterar un array que tengo en mapstate tengo que indicar una :key  -->
            <li v-for="(item, index) of frutas" :key="item" @click="aumentar(index)"
                 class="list-group-item d-flex justify-content-between align-items-center">
                {{index}} - {{item.nombre}}
                <span class="badge badge-primary badge-pill">{{item.cantidad}}</span>
            </li>
            
        </ul>
        <button class=" btn btn-danger btn-block" @click="borrarCantidades" >Borrar cantidades</button>
    </div>
</template>

<script>

    import {mapState, mapMutations} from 'vuex';

    export default {
        name:'Lista',
        computed:{
            ...mapState(['frutas']),
        }, 
        methods:{
            ...mapMutations(['aumentar', 'borrarCantidades'])
        }


    }

</script>